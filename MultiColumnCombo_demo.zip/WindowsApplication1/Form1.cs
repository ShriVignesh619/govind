using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace WindowsApplication1
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form{
		private System.Windows.Forms.Button button1;
		private MyCustomControls.InheritedCombo.MultiColumnComboBox multiColumnComboBox1;
		private System.ComponentModel.IContainer components;
		private DataTable dtable;

		public Form1(){
			InitializeComponent();
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		public static void Main(string[] args)	{
			Application.Run(new Form1());
		}
		
		protected override void Dispose( bool disposing )	{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			this.button1 = new System.Windows.Forms.Button();
			this.multiColumnComboBox1 = new MyCustomControls.InheritedCombo.MultiColumnComboBox(this.components);
			this.SuspendLayout();
			// 
			// button1
			// 
			this.button1.Location = new System.Drawing.Point(208, 96);
			this.button1.Name = "button1";
			this.button1.TabIndex = 1;
			this.button1.Text = "Load";
			this.button1.Click += new System.EventHandler(this.button1_Click);
			// 
			// multiColumnComboBox1
			// 
			this.multiColumnComboBox1.Location = new System.Drawing.Point(24, 16);
			this.multiColumnComboBox1.Name = "multiColumnComboBox1";
			this.multiColumnComboBox1.Size = new System.Drawing.Size(152, 21);
			this.multiColumnComboBox1.TabIndex = 4;
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(296, 133);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.multiColumnComboBox1,
																		  this.button1});
			this.Name = "Form1";
			this.Text = "Multi Column Combo Test";
			this.ResumeLayout(false);

		}
		#endregion

		private void button1_Click(object sender, System.EventArgs e) {
			CreateDataTable();
			multiColumnComboBox1.Table = dtable;
			multiColumnComboBox1.DisplayMember = "Band";
			multiColumnComboBox1.ColumnsToDisplay = new string[]{"Band","Song","Album"};
			button1.Enabled = false;
		}

		private void CreateDataTable(){
			dtable = new DataTable("Rock");
			//set columns names
			dtable.Columns.Add("Band",typeof(System.String));
			dtable.Columns.Add("Song",typeof(System.String));
			dtable.Columns.Add("Album",typeof(System.String));

			//Add Rows
			DataRow drow = dtable.NewRow();
			drow["Band"] = "Iron Maiden";
			drow["Song"] = "Wasted Years";
			drow["Album"] = "Ed Hunter";
			dtable.Rows.Add(drow);

			drow = dtable.NewRow();
			drow["Band"] = "Metallica";
			drow["Song"] = "Enter Sandman";
			drow["Album"] = "Metallica";
			dtable.Rows.Add(drow);
			
			drow = dtable.NewRow();
			drow["Band"] = "Jethro Tull";
			drow["Song"] = "Locomotive Breath";
			drow["Album"] = "Aqualung";
			dtable.Rows.Add(drow);
			
			drow = dtable.NewRow();
			drow["Band"] = "Mr. Big";
			drow["Song"] = "Seven Impossible Days";
			drow["Album"] = "Japandemonium";
			dtable.Rows.Add(drow);
		}
	}
}
